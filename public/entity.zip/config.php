<?php
$entity_api_key = 'YOUR_APIKEY_HERE'; // REQUIRED, PASTE YOUR API KEY HERE
?>
